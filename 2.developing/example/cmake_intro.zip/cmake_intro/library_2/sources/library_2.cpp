#include "../library_2.h"

#include <iostream>

void Library2::ShowCaption()
{
	std::cout << "Library 2" << std::endl;
}
