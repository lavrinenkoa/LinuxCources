#ifndef LIBRARY_2_H
#define LIBRARY_2_H

namespace Library2
{
	void ShowCaption();
}

#endif//LIBRARY_2_H
