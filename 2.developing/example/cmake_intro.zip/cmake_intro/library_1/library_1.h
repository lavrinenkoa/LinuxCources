#ifndef LIBRARY_1_H
#define LIBRARY_1_H

class Object
{
public:
	Object();
	virtual ~Object();

	int execute() const;
};

#endif//LIBRARY_1_H
